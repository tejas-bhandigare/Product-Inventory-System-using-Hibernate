package org.example;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import java.util.List;
import java.util.Scanner;
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
        SessionFactory factory =cfg.buildSessionFactory();
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n  Product Inventory Menu ");
            System.out.println("1. Add Product");
            System.out.println("2. View All Products");
            System.out.println("3. Update Product");
            System.out.println("4. Delete Product");
            System.out.println("5. Search Product by Category");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            Session session =factory.openSession();
            Transaction tx = session.beginTransaction();

            switch (choice){
                case 1:
                    System.out.println("Enter Product Name : ");
                    String name = sc.nextLine();
                    System.out.print("Enter Category: ");
                    String category = sc.nextLine();
                    System.out.print("Enter Price: ");
                    double price = sc.nextDouble();
                    System.out.print("Enter Quantity: ");
                    int quantity = sc.nextInt();

                    Product product = new Product(name, category, price, quantity);
                    session.persist(product);
                    System.out.println("Product added successfully!");
                    break;

                case 2:
                    List<Product> products = session.createQuery("from Product", Product.class).list();
                    for (Product p : products) {
                        System.out.println(p);
                    }
                    break;

                case 3:
                    System.out.print("Enter Product ID to update: ");
                    int id = sc.nextInt();
                    Product p1 = session.find(Product.class, id);
                    if (p1 != null) {
                        System.out.print("Enter new price: ");
                        double newPrice = sc.nextDouble();
                        System.out.print("Enter new quantity: ");
                        int newQty = sc.nextInt();
                        p1.setPrice(newPrice);
                        p1.setQuantity(newQty);
                        session.merge(p1);
                        System.out.println("Product updated!");
                    } else {
                        System.out.println("Product not found!");
                    }
                    break;

                case 4:
                    System.out.print("Enter Product ID to delete: ");
                    int delId = sc.nextInt();
                    Product delProduct = session.find(Product.class, delId);
                    if (delProduct != null) {
                        session.remove(delProduct);
                        System.out.println("Product deleted!");
                    } else {
                        System.out.println("Product not found!");
                    }
                    break;

                case 5:
                    System.out.print("Enter Category to search: ");
                    String searchCat = sc.nextLine();
                    List<Product> result = session
                            .createQuery("from Product where category = :cat", Product.class)
                            .setParameter("cat", searchCat)
                            .list();
                    if (result.isEmpty())
                        System.out.println("No products found in this category.");
                    else
                        result.forEach(System.out::println);
                    break;

                case 6:
                    System.out.println("👋 Exiting...");
                    factory.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice! Try again.");
            }

            tx.commit();
            session.close();
        } while (true);

    }
}